# Title: Loading required R packages
# Inputs: N/A
# Outputs: N/A
# Description: loads required packages for the binomial package

#' @import ggplot2
#' @import testthat
#' @name pkgname
#' @docType package
NULL
