## ---- include = FALSE----------------------------------------------------
knitr::opts_chunk$set(
  collapse = TRUE,
  comment = "#>"
)

## ------------------------------------------------------------------------
library(binomial)

## ------------------------------------------------------------------------
# bin_choose function
bin_choose(n = 10, k = 5)

#bin_probability function
bin_probability(success = 5, trials = 10, prob = 0.5)

## ------------------------------------------------------------------------
# Binomial Distribution
bin_distribution(10, 0.5)

# Plotting
plot(bin_distribution(10, 0.5))

## ------------------------------------------------------------------------
# Culumlative Distribution
bin_cumulative(10, 0.5)

# Plotting
plot(bin_cumulative(10, 0.5))

## ------------------------------------------------------------------------
# defining a binomial variable
variable <- bin_variable(10, .5)

# Priting general summary
variable

# Printing longform summary
var.summary <- summary(variable)
var.summary

## ------------------------------------------------------------------------
bin_mean(10, 0.5)
bin_variance(10, 0.5)
bin_mode(10, 0.5)
bin_kurtosis(10, 0.5)
bin_skewness(10, 0.5)

